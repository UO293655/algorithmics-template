package algstudent.s6;


public class Main {

	public static void main(String[] args) {
		long t1, t2 = 0;
		NumericSquareOne n = new NumericSquareOne("files/test07.txt");
		System.out.println("Let's start solving!");
		t1 = System.currentTimeMillis();
		n.solve();
		t2 = System.currentTimeMillis();
		System.out.println("SOLUTION FOUND:\n");
		n.printSolution();
		System.out.println();
		System.out.println("Time elapsed (ms): " + (t2 - t1));
		
		System.out.println("\n\n");
		

	}

}
