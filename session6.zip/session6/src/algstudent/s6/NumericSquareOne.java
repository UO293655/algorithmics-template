package algstudent.s6;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class NumericSquareOne {
	
	private final static int UNKNOWN = -1;
	
	private int size;
	private int[][] numbers;
	private char[][] operations;
	private int[] solution;
	private int[][] finalNumbers;
	boolean found;
	
	public NumericSquareOne(String filename) {
		extractData(filename);
	}
	
	private void extractData(String filename) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(filename)); 
			size = Integer.parseInt(reader.readLine());
			numbers = new int[size][size];
			solution = new int[2*size];
			operations = new char[2*size][size];
			parseData(reader);
			reader.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	private void parseData(BufferedReader reader) throws IOException{
		String[] line1, line2 = null;
		for(int i = 0; i < size; i++) {
			line1 = reader.readLine().split(" ");
			line2 = reader.readLine().split(" ");
			parseLine1(line1, i);
			parseLine2(line2, i);
		}
		String[] lastLine = reader.readLine().split(" ");
		parseLastLine(lastLine);
	}
	
	private void parseLine1(String[] line, int row) {
		int number;
		char operation;
		for(int i = 0; i < size * 2; i += 2) {
			number = line[i].charAt(0) == '?'? UNKNOWN : Integer.parseInt(line[i]);
			operation = line[i + 1].charAt(0);
			numbers[row][i / 2] = number;
			operations[row][i / 2] = operation;
		}
		
		solution[row] = Integer.parseInt(line[line.length - 1]);
	}
	
	private void parseLine2(String[] line, int row) {
		for(int i = 0; i < line.length; i++) {
			operations[size + row][i] = line[i].charAt(0);
		}
	}
	
	private void parseLastLine(String[] line) {
		for(int i = 0; i < line.length; i++) {
			solution[size + i] = Integer.parseInt(line[i]);
		}
	}
	
	public void solve() {
		finalNumbers = copyNumbers();
		backtracking(0, 0);
	}
	
	private int[][] copyNumbers(){
		int[][] copy  = new int[size][size];
		for(int i = 0; i < size; i ++)
			for(int j = 0; j < size; j++) 
				copy[i][j] = numbers[i][j];
		
		return copy;

	}
	
	private void backtracking(int row, int col){
		
		
		if (numbers[row][col] == UNKNOWN) {
			for (int i = 1; i < 10 && !found; i++) {
			
				finalNumbers[row][col] = i;
				if (row == size - 1 && col == row) {
					if (checkCol(col) && checkRow(row))
						found = true;
					else if( i == 9) {
						finalNumbers[row][col] =  UNKNOWN;
						return;
					}
				}
				else if(row == size -1 && checkCol(col))
					backtracking(row, col + 1);
				
				else if(checkRow(row))
					backtracking(row + 1 , 0);
				
				else if(col == size -1 && i == 9) {
					finalNumbers[row][col] = UNKNOWN;
					return;	
				}
				
				else if(col != size - 1)
					backtracking(row, col + 1);
				}
				
		}else if(found) return;
		else if(row == size - 1 && col == row) {
			if(checkRow(row) && checkCol(col)) {
				found = true;
			}else
				return;
		}
		else if(row == size - 1) {
			if(checkRow(row)) {
				backtracking(row, col+1);
			}else {
				return;
			}
		}
		else if(col == size - 1) {
			if(checkRow(row)) {
				backtracking(row+1, 0);
			}else
				return;
		}else
			backtracking(row,col+1);
	}



	private boolean checkRow(int row) {
		int expected = solution[row];
		int actual = finalNumbers[row][0];
		for(int i = 1; i < size; i++) {
			switch(operations[row][i - 1]) {
			case('+'):
				actual += finalNumbers[row][i];
				break;
			case('-'):
				actual -= finalNumbers[row][i];
				break;
			case('*'):
				actual *= finalNumbers[row][i];
			case('/'):
				if(actual % finalNumbers[row][i] != 0)
					return false;
				actual /= finalNumbers[row][i];
			break;
			}
		}
		return expected == actual;
	}
	

	private boolean checkCol(int col) {
		int expected = solution[size + col];
		int actual = finalNumbers[0][col];
		for(int i = 1; i < size; i++) {
			switch(operations[size + col][i]) {
			case('+'):
				actual += finalNumbers[i][col];
				break;
			case('-'):
				actual -= finalNumbers[i][col];
				break;
			case('*'):
				actual *= finalNumbers[i][col];
			case('/'):
				if(actual % finalNumbers[i][col] != 0)
					return false;
				actual /= finalNumbers[i][col];
				break;
				}
		}
		return expected == actual;
	}
	
	public void printSolution() {
		for(int i = 0; i < finalNumbers.length; i++) {
			for(int j = 0; j < finalNumbers[i].length; j++) {
				System.out.print(finalNumbers[i][j] + " \t");
			}
			System.out.println();
		}
	}

	
}
