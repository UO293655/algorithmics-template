import Helper as h

def visitedAll(visited):
    for i in range(len(visited)):
        if(not visited[i]):
           return False
    return True

def printPrim(T, cost, C):
    print("TOTAL OPTIMAL COST: {0}\n*********************\nSELECTED EDGES=".format(cost))
    for i in range(len(C)):
        print("EDGE NUMBER {0} : FROM NODE = {1} TO NODE {2} *** COST = {3}".format(i, T[i][0], T[i][1], C[i]))

def Prim(filename):
    T = []
    C = []
    totalCost = 0
    G = h.triangularMatrixFromFile(filename)
    visited = [False] * len(G[0])
    U = 0
    V = 0
    cost = 1000
    visited[0] = True
    while not(visitedAll(visited)):
        for u in range(len(visited)):
            if(visited[u]):
                for v in range(len(visited)):
                    if(u < v):
                        if(G[u][v] < cost and not visited[v]):
                            cost = G[u][v]
                            V = v
                            U = u
                    else:
                        if(G[v][u] < cost and not visited[v]):
                            cost = G[v][u]
                            V = v
                            U = u

        T.append([U, V])
        C.append(cost)
        visited[V] = True
        totalCost +=  cost
        cost = 1000

    return T, totalCost, C

def Prim2(G):
    T = []
    C = []
    totalCost = 0
    visited = [False] * len(G[0])
    U = 0
    V = 0
    cost = 1000
    visited[0] = True
    while not(visitedAll(visited)):
        for u in range(len(visited)):
            if(visited[u]):
                for v in range(len(visited)):
                    if(u < v):
                        if(G[u][v] < cost and not visited[v]):
                            cost = G[u][v]
                            V = v
                            U = u
                    else:
                        if(G[v][u] < cost and not visited[v]):
                            cost = G[v][u]
                            V = v
                            U = u

        T.append([U, V])
        C.append(cost)
        visited[V] = True
        totalCost +=  cost
        cost = 1000

    return T, totalCost, C
