package algstudent.s6;


public class Main {

	public static void main(String[] args) {
		long t1, t2 = 0;
		NumericSquareOne n = new NumericSquareOne("files/test00.txt");	
		t1 = System.currentTimeMillis();
		n.solve();
		t2 = System.currentTimeMillis();
		n.printSolution();
		System.out.println(t2 - t1);

	}

}
