package algstudent.s3;

public class Mergesort {

	public static void mergeSort(int[] v) {
	    mergeSort(v, v.length);
	}

	private static void mergeSort(int[] v, int n) {
		if(n < 2) return;
		
		int middle = n/2;
		int[] left = new int[middle];
		int[] right = new int[n - middle];
		
		for (int i = 0; i < middle; i++) {
	        left[i] = v[i];
	    }
	    for (int i = middle; i < n; i++) {
	        right[i - middle] = v[i];
	    }
	    
	    mergeSort(left, middle);
	    mergeSort(right, n - middle);
	    
	    merge(v, left, right, middle, n - middle);
	}

	private static void merge(int[] v, int[] l, int[] r, int left, int right) {
		 int i = 0;
		 int j = 0; 
		 int k = 0;
		 
		    while (i < left && j < right) {
		        if (l[i] <= r[j]) {
		            v[k++] = l[i++];
		        }
		        else {
		            v[k++] = r[j++];
		        }
		    }
		    while (i < left) {
		        v[k++] = l[i++];
		    }
		    while (j < right) {
		        v[k++] = r[j++];
		    }
		
	}
	
}
