import Helper as h
import Prim as p
import time as t

size = 256
while True:
    #Do prim
    matrix = h.triangularMatrixRandomIntegers(size, 100, 999)
    t1 = t.time()
    p.Prim2(matrix)
    t2 = t.time()
    elapsed = t2 - t1
    print("Size: " + str(size) + "\tElapsed time: " + str(elapsed) + "\n")
    size *= 2