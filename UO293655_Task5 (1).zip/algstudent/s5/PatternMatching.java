package algstudent.s5;

public class PatternMatching {
	
	private String text;
	private boolean[][] table;	
	private String pattern;
	public PatternMatching(String text) {
		this.text = text;
	}
	
	public boolean checkPattern(String pattern) {
		this.pattern =  pattern;
		table = new boolean[text.length() + 1][pattern.length() + 1];
		table[0][0] = true;
		for(int i = 1; i < table.length; i++)
			table[i][0] = false;
		for(int i = 1; i < table[0].length; i++)
			table[0][i] = false;
		
		for(int i = 1;  i < table.length; i++) 
			for(int j = 1; j < table[i].length; j++) {
				if(text.charAt(i - 1) == pattern.charAt(j - 1)) 
					table[i][j] = table[i - 1][j - 1];
				else {
					if(pattern.charAt(j - 1) == '?') 
						table[i][j] = (table[i - 1][j - 1] || table[i][j - 1]);
					else if(pattern.charAt(j - 1) == '*')
						table[i][j] = (table[i - 1][j - 1] || table[i][j - 1] || table[i - 1][j]);
					else
						table[i][j] = false;
				}
			}
		
		return table[table.length - 1][table[0].length - 1];
	}
	
	public void printsTable() {
		
		String newPattern = "  " + pattern;
		String newText = "  " + text;
		
		System.out.println();
		
		for(int i = 0; i < table.length + 1; i++) {
			for(int j = 0; j < table[0].length + 1; j++) {
				if(i == 0)
					System.out.print(newPattern.charAt(j) + "\t");
				else if(j == 0)
					System.out.print(newText.charAt(i) + "\t");
				else if(table[i - 1][j - 1])
					System.out.print("T\t");
				else
					System.out.print("F\t");
			}
			System.out.println("\n");
		}
		
		System.out.println();
		
	}

}
