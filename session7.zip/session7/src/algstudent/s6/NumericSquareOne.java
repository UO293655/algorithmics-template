package algstudent.s6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class NumericSquareOne {
	
	private final static int UNKNOWN = Integer.MAX_VALUE;
	
	private int size;
	private int[][] numbers;
	private char[][] operations;
	private int[][] results;
	private int[][] solution;
	private boolean found;
	private int developedNodes = 0;
	
	public NumericSquareOne(String filename) {
		extractData(filename);
	}
	
	private void extractData(String filename) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(filename));
			size = Integer.parseInt(reader.readLine());
			numbers = new int[size][size];
			operations = new char[2 * size][size];
			results = new int[2][size];
			solution = new int[size][size];
			parseData(reader);
			reader.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Data successfully extracted.");
		printData();
		
	}
	
	
	private void parseData(BufferedReader reader) throws IOException{
		for(int lineNumber = 1; lineNumber <= size * 2; lineNumber++) {
			String[] line = reader.readLine().split(" ");
			switch(lineNumber%2) {
			case(1):
				parseLine1(line, (lineNumber - 1) / 2);
				break;
			case(0):
				parseLine2(line, lineNumber / 2 - 1);
				break;
			}
		}
		parseLastLine(reader.readLine().split(" "));
	}
	
	private void parseLastLine(String[] line) {
		for(int col = 0; col < size; col++) 
			results[1][col] = Integer.parseInt(line[col]);
	}
	
	private void parseLine1(String[] line, int row) {
		for(int col = 0; col < 2 * size - 1; col++) {
			switch(col % 2) {
			case(0):
				numbers[row][col / 2] = line[col].equals("?")? UNKNOWN : Integer.parseInt(line[col]);
				solution[row][col / 2] = numbers[row][col / 2];
				break;
			case(1):
				operations[row][(col - 1) / 2] = line[col].charAt(0);
				break;
			}
		}
		operations[row][size - 1] = '=';
		results[0][row] = Integer.parseInt(line[line.length - 1]);
	}
	
	private void parseLine2(String[] line, int row) {
		for(int col = 0; col < size; col++) {
			operations[size + row][col] = line[col].charAt(0);
		}
	}
	
	private void printData() {
		System.out.println("Size: " + size);
		for(int row = 0; row < size; row++) {
			for(int col = 0; col < size; col++) {
				if(numbers[row][col] == UNKNOWN)
					System.out.print("? ");
				else
					System.out.print(numbers[row][col] + " ");
				System.out.print(operations[row][col]  + " ");
			}
			System.out.println(results[0][row]);
			for(int col = 0; col < size; col ++) {
				System.out.print(operations[size + row][col] + "   ");
			}
			System.out.println();
		}
		
		for(int col = 0; col < size; col++)
			System.out.print(results[1][col] + "   ");
		System.out.println();
	}
	
	public void solve() {
		backtracking(0, 0);
		if(!found)
			System.out.println("NO SOLUTION FOUND!");
	}
	
	private void backtracking(int row, int col) {
	
		if(found)
			return;
		
		developedNodes++;
		
		if(numbers[row][col] == UNKNOWN) {
			for(int val = 0; val < 10 && !found; val ++) {
				solution[row][col] = val;
				if(isSolution()) {
					found = true;
					return;
				}else {
					if(row == col && row == size - 1)
						continue;
					else if(canBeSolution(row, col)) {
						if(col == size - 1)
							backtracking(row + 1, 0);
						else
							backtracking(row, col + 1);
					}
				}
			}
		}else {
			if(row == col && row == size - 1)
				return;
			else if(canBeSolution(row, col) && !found) {
				if(col == size - 1)
					backtracking(row + 1, 0);
				else
					backtracking(row, col + 1);
			}
		}
	}

	private boolean isSolution() {
		for(int row = 0; row < size; row++) 
			for(int col = 0; col < size; col++)
				if(solution[row][col] == UNKNOWN)
					return false;
		
		for(int check = 0; check < size; check ++) {
			if(!(checkRow(check) && checkCol(check)))
				return false;
		}
		
		return true;
	}
	
	private boolean checkRow(int row) {
		int expected = results[0][row];
		int actual = solution[row][0];
		for(int col = 0; col < size - 1; col++) {
			switch(operations[row][col]) {
			case('+'): actual += solution[row][col + 1];
				break;
			case('-'): actual -= solution[row][col + 1];
				break;
			case('*'): actual *= solution[row][col + 1];
				break;
			case('/'):
				if(solution[row][col + 1] == 0 || actual % solution[row][col + 1] != 0)
					return false;
				else
					actual /= solution[row][col + 1];
			}
		}
		
		return expected == actual;
	}
	
	private boolean checkCol(int col) {
		int expected = results[1][col];
		int actual = solution[0][col];
		for(int row = 0; row < size - 1; row++) {
			switch(operations[row + size][col]) {
			case('+'): actual += solution[row + 1][col];
				break;
			case('-'): actual -= solution[row + 1][col];
				break;
			case('*'): actual *= solution[row + 1][col];
				break;
			case('/'):
				if(solution[row + 1][col] == 0 || actual % solution[row + 1][col] != 0)
					return false;
				else
					actual /= solution[row + 1][col];
				break;
			}
		}
		
		return expected == actual;
	}
	
	public void printSolution() {
		for(int row = 0; row < size; row++) {
			for(int col = 0; col < size; col++) {
				System.out.print(solution[row][col] + " ");
				System.out.print(operations[row][col]  + " ");
			}
			System.out.println(results[0][row]);
			for(int col = 0; col < size; col ++) {
				System.out.print(operations[size + row][col] + "   ");
			}
			System.out.println();

		}
		
		for(int col = 0; col < size; col++)
			System.out.print(results[1][col] + "   ");
		System.out.println();
		System.out.println("Nodes developed: " + developedNodes);
	}
	
	private boolean canBeSolution(int row, int col) {
		if(col == size - 1)
			return checkRow(row);
		if(row == size - 1)
			return checkCol(col);
		
		return true;
	}
}


